"""
    file: squares.py
    description: Draw a recursive set of squares
    language: python 3
    author: Lindy Quach
    section: 3 (Group A)
"""


import turtle as tp


def init_canvas(size):
    """
    precondition: canvas size has been inputted
    precondition: Location: (0, 0)
    precondition: Turtle is facing east
    precondition: Pensize is 1
    postcondition: canvas has been set up
    purpose: Initializing canvas and turtle
    credit to Professor Ben Steele for source code
    :param size: length of a side of the first square drawn
    :return: canvas and turtle has been initialized
    """
    tp.reset()
    tp.setup(tp.window_height(), tp.window_height())
    margin = 20
    # scale size up so that there is room for recursive drawing
    size = size * 2
    # span is the additional margin needed for recursion.
    span = size / 4
    tp.setworldcoordinates(-span-margin, -margin, size-span+margin, size+margin)
    tp.pensize(1)


def draw_squares(depth, size):
    """
    precondition: canvas and depth level has been initialized
    postcondition: canvas and depth level has been set up
    purpose: Draw a recursive set of squares based on depth and pixel size
    :param depth: recursive level of images
    :param size: pixel size
    :return: recursive image of squares
    """
    if depth == 0:
        return
    elif depth % 2:
        tp.pencolor('purple')
    else:
        tp.pencolor('blue')
    tp.lt(90)
    tp.fd(size)
    tp.rt(90)
    tp.fd(size)
    draw_squares(depth-1, size*(1/3))
    tp.up()
    tp.bk(size*(4/3))
    tp.down()
    draw_squares(depth-1, size*(1/3))
    tp.up()
    tp.fd(size * (4/3))
    tp.down()
    tp.rt(90)
    tp.fd(size)
    tp.rt(90)
    tp.fd(size)
    tp.rt(180)
    # change color with depth + 1
    if (depth + 1) % 2:
        tp.pencolor('purple')
    else:
        tp.pencolor('blue')


def main():
    """
    precondition: turtle has been imported and initialized
    postcondition: canvas and depth level has been set up
    purpose: Get user input for canvas size, depth level, pixel size
    and inform user to close window when program is done running
    :return: recursive image of squares
    """
    size = input('What is the canvas size? ')
    if size == '':
        canvas_size = 600
    else:
        canvas_size = int(size)
    init_canvas(canvas_size)
    depth = int(input('What is the depth of the image? '))
    pixel_size = int(input('How long should the lines of depth 1 be? '))
    draw_squares(depth, pixel_size)
    print('Close the canvas to quit.')
    tp.done()


if __name__ == '__main__':
    main()
